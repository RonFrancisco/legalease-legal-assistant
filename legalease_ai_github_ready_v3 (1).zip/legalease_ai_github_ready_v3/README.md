# LegalEase AI (MVP)

This repo is **ready for Streamlit Cloud**. Keep `app.py` in the root.

## Deploy on Streamlit Community Cloud
1. Create a repo on GitHub and upload these files (ensure `app.py` is at the root).
2. Go to Streamlit Community Cloud → **New app**.
3. Select: repo, branch, main file path = `app.py`.
4. In **App → Settings → Secrets**, add:
   ```
   OPENAI_API_KEY = sk-...
   ```
5. Click **Deploy**.

Your app URL will look like: `https://<your-app>.streamlit.app`.

## Local run
```
pip install -r requirements.txt
export OPENAI_API_KEY=sk-...
streamlit run app.py
```

## Notes
- Long documents are truncated for MVP to avoid token limits.
- Keep a human in the loop; this is not legal advice.