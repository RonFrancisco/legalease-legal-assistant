import os
import io
import fitz  # PyMuPDF
import docx
import streamlit as st
from openai import OpenAI

st.set_page_config(page_title="LegalEase AI", page_icon="⚖️", layout="centered")
st.title("⚖️ LegalEase AI")
st.subheader("AI Legal Assistant for Lawyers (MVP)")

# Load API key
api_key = None
try:
    api_key = st.secrets.get("OPENAI_API_KEY", None)
except Exception:
    api_key = None
if not api_key:
    api_key = os.getenv("OPENAI_API_KEY", None)
if not api_key:
    st.warning("⚠️ Set an OpenAI API key in App Settings → Secrets (OPENAI_API_KEY).")
client = OpenAI(api_key=api_key) if api_key else None

def extract_text_from_pdf(uploaded_file) -> str:
    data = uploaded_file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    return "\n".join(page.get_text() for page in doc)

def extract_text_from_docx(uploaded_file) -> str:
    data = uploaded_file.read()
    d = docx.Document(io.BytesIO(data))
    return "\n".join(p.text for p in d.paragraphs)

def extract_text_from_txt(uploaded_file) -> str:
    data = uploaded_file.read()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="ignore")

def truncate_for_tokens(text: str, max_chars: int = 30000) -> str:
    return text if len(text) <= max_chars else text[:max_chars] + "\n\n[...truncated for MVP token limit...]"

def summarize_text_legal_style(text: str) -> str:
    if not client:
        return "OpenAI API key not configured."
    system = ("You are a meticulous legal assistant. Produce a formal, concise legal-style summary. "
              "Highlight: (1) key facts, (2) material clauses/terms, (3) obligations & deadlines, "
              "(4) risks/exposures, (5) open issues. Use clear headings and bullet points.")
    user = f"Summarize the following document:\n\n{text}"
    resp = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": user}],
        temperature=0.2,
        max_tokens=900,
    )
    return resp.choices[0].message.content.strip()

def generate_legal_draft(prompt_text: str) -> str:
    if not client:
        return "OpenAI API key not configured."
    system = ("You are a legal writer. Draft a professional, well-structured legal document based on the user's instruction. "
              "Include placeholders for party names, dates, and amounts when needed.")
    user = f"Draft request:\n{prompt_text}"
    resp = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": user}],
        temperature=0.2,
        max_tokens=1000,
    )
    return resp.choices[0].message.content.strip()

task = st.selectbox("What do you want to do?", ["Summarize a Document", "Generate a Draft"])

if task == "Summarize a Document":
    uploaded = st.file_uploader("Upload a legal document (PDF, DOCX, or TXT)", type=["pdf", "docx", "txt"])
    if uploaded is not None:
        ext = (uploaded.name.split(".")[-1] or "").lower()
        with st.spinner("Extracting text..."):
            if ext == "pdf":
                text = extract_text_from_pdf(uploaded)
            elif ext == "docx":
                text = extract_text_from_docx(uploaded)
            elif ext == "txt":
                text = extract_text_from_txt(uploaded)
            else:
                st.error("Unsupported file type."); text = ""
        if text:
            st.info(f"Characters extracted: {len(text):,}")
            trimmed = truncate_for_tokens(text)
            if len(text) != len(trimmed):
                st.warning("Long document detected. Trimmed for MVP to avoid token limits.")
            if st.button("Generate Legal Summary"):
                with st.spinner("Summarizing with GPT-4o..."):
                    summary = summarize_text_legal_style(trimmed)
                st.success("Summary generated")
                st.text_area("Legal Summary", summary, height=350)
                st.download_button("Download Summary (.txt)", summary, file_name="summary.txt")

elif task == "Generate a Draft":
    prompt_text = st.text_area("Describe the draft you need (e.g., 'Demand letter for unpaid rent in Belgium, include 14-day cure period').")
    if st.button("Generate Draft"):
        if prompt_text.strip():
            with st.spinner("Drafting with GPT-4o..."):
                draft = generate_legal_draft(prompt_text.strip())
            st.success("Draft generated")
            st.text_area("Legal Draft", draft, height=400)
            st.download_button("Download Draft (.txt)", draft, file_name="draft.txt")
        else:
            st.warning("Please provide an instruction for the draft.")